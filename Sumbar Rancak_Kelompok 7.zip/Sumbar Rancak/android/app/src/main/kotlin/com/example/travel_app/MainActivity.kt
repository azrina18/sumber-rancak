package com.example.travel_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
