class Place {
  final String imageUrl;
  final String country;
  final String city;
  final String description;
  final String event;

  Place({this.city, this.country, this.description, this.imageUrl, this.event});
}

final places = [
  Place(
      imageUrl: "assets/air-terjun.png",
      city: "Air terjun proklamator",
      country: "Indonesia",
      description:
          "Air terjun ini termasuk salah satu destinasi baru di Sumatra Barat. Diberi nama Proklamator, karena air terjun ini ditemukan pertama kali oleh Mahasiswa Pecinta Alam Proklamator, Universitas Bung Hatta, saat membuka jalur pendakian dikawasan tersebut pada tahun 2020, beberapa waktu lalu."),
  Place(
      imageUrl: "assets/sanjai-rina.png",
      city: "Sanjai Rina",
      country: "Indonesia",
      description:
          "sanjai merupakan makanan khas dari daerah Sumatera Barat. Sanjai merupakan makanan atau keripik yang dibuat dari ubi/singkong. Sanjai memiliki berbagai macam varian mulai dari yang manis hingga yang pedas. Sanjai Rina merupakan salah satu outlet pusat oleh-oleh yang terletak di kota Payakumbuh Sumatera Barat. Sanjai Rina menyediakan berbagai macam makanan dan oleh-oleh tidak hanya keripik singkong melainkan juga ada kue, gelamai dan beras rendang."),
  Place(
      imageUrl: "assets/danau-singkarak.png",
      city: "Danau Singkarak",
      country: "Indonesia",
      description:
          "Danau Singkarak adalah sebuah danau yang membentang di dua kabupaten yang terdapat di provinsi Sumatra Barat, Indonesia, yaitu kabupaten Solok dan kabupaten Tanah Datar. Danau ini memiliki luas 107,8 km² dan merupakan danau terluas kedua di pulau Sumatra setelah danau toba di Sumatra Utara."),
  Place(
      imageUrl: "assets/lembah-harau.png",
      city: "Lembah Harau",
      country: "Indonesia",
      description:
          "Lembah Harau dijuluki juga dengan nama Lembah Yosemite, dan menjadi salah satu lembah terindah di Indonesia. Dijuluki Lembah Yosimite karena mengingatkan pada keindahan Taman Nasional Yosemite di Sierra Nevada California yang terkenal. Lembah Harau memiliki air terjun bernama Bunta Waterfall, atau yang oleh masyarakat lokal disebut Sarasah Bunta. Air terjun ini mengalirkan air tawar segar dari dataran tinggi. Disebut Air Terjun Bunta, karena ia berunta-unta indah apabila terpancar sinar matahari. Selain itu, Lembah Harau juga terdiri dari tiga kawasan, yaitu Resort Aka Barayun, Resort Sarasah Bunta, dan Resort Rimbo Piobang."),
  Place(
      imageUrl: "assets/pantai-manis.png",
      city: "Pantai Air Manis",
      country: "Indonesia",
      description:
          "Pantai Air Manis termasuk pantai di Kota Padang yang meskipun tidak luput digerus ombak, masih terasa luas dan landai. Saking luasnya, mobil pengunjung pun bisa hilir mudik di pasirnya yang membentang lega, padat putih dan bersih. Pantai Air Manis juga terkenal dengan legenda Malin Kundangnya. Legenda yang mengisahkan seorang anak durhaka yang berubah jadi batu akibat kutukan ibu kandungnya. Gundukan batu disisi selatan pantai, yang di salah satu bagiannya berbentuk manusia sedang sujud konon adalah sosok si anak durhaka yang bernama Malin Kundang yang membatu beserta istri dan kru kapal serta kapalnya."),
  Place(
      imageUrl: "assets/jam-gadang.png", //
      city: "Jam Gadang",
      country: "Indonesia",
      description:
          "Jam Gadang adalah menara jam yang menjadi penanda atau ikon Kota Bukittinggi, Sumatra Barat, Indonesia. Menara jam ini memiliki jam dengan ukuran besar di empat sisinya sehingga dinamakan Jam Gadang, sebutan bahasa Minangkabau yang berarti jam besar."),
  Place(
      imageUrl: "assets/pantai-carocok.png",
      city: "Pantai Carocok",
      country: "Indonesia",
      description:
          "Pantai Carocok Painan merupakan salah satu obyek wisata yang ramai dikunjungi oleh masyarakat lokal di Sumatera Barat. Memiliki jarak tempuh sekitar 77 kilometer dari Kota Padang dan ditempuh dalam waktu dua jam. Di Pantai Carocok Painan memiliki jembatan yang menghubungkan dengan Pulau Batu Kareta. Wisatawan dapat menyeberang dengan berjalan kaki. Tidak jauh dari Pulau Batu Kareta, wisatawan dapat menyeberang ke Pulau Cingkuak menggunakan perahu."),
  Place(
      imageUrl: "assets/istano-basa-pagaruyuang.png",
      city: "Istano basa pagaruyuang",
      country: "Indonesia",
      description:
          "Istano Basa yang lebih terkenal dengan nama Istana Pagaruyung adalah museum berupa replika istana Kerajaan Pagaruyung terletak di Nagari Pagaruyung, Kecamatan Tanjung Emas, Kabupaten Tanah Datar, Sumatra Barat. Istana ini berjarak lebih kurang 5 kilometer dari Batusangkar."),
  Place(
      imageUrl: "assets/rumah-kelahiran bung-hatta.png",
      city: "Kelahiran Bung Hatta",
      country: "Indonesia",
      description:
          "Rumah Kelahiran Bung Hatta adalah rumah yang dibangun sebagai upaya mengenang dan memperoleh gambaran tempat Bung Hatta dilahirkan dan menghabiskan masa kecilnya sampi berusia 11 tahun. Selanjutnya Bung Hatta melanjutkan pendidikan menengahnya di Meer Uitgebred Lager Onderwijs atau sekolah menengah di kota Padang."),
  Place(
      imageUrl: "assets/museum-adityawarman.png",
      city: "Museum adityawarman",
      country: "Indonesia",
      description:
          "Pada tanggal 28 Mei 1979, museum ini secara resmi diberi nama ‘Adityawarman’. Nama museum ini diambil dari nama salah satu raja yang pernah berkuasa di Minangkabau antara1347-1375 M. Dalam tinjauan sejarah, Raja Adityawarman merupakan salah satu raja Minangkabau yang berasal dari trah kebangsawanan Majapahit.Raja Adityawarman sendiri diperkirakan berkuasa pada era yang sama dengan periode sejarah saat Gajah Mada menjabat sebagai Mahapatih (1334-1364 M)."),
];

final events = [
  Place(
      imageUrl: "assets/air-terjun.png",
      city: "Air terjun proklamator",
      country: "Indonesia",
      description:
          "Air terjun ini termasuk salah satu destinasi baru di Sumatra Barat. Diberi nama Proklamator, karena air terjun ini ditemukan pertama kali oleh Mahasiswa Pecinta Alam Proklamator, Universitas Bung Hatta, saat membuka jalur pendakian dikawasan tersebut pada tahun 2020, beberapa waktu lalu.",
      event: ""),
  Place(
      imageUrl: "assets/museum-adityawarman.png",
      city: "Museum adityawarman",
      country: "Indonesia",
      description:
          "Pada tanggal 28 Mei 1979, museum ini secara resmi diberi nama ‘Adityawarman’. Nama museum ini diambil dari nama salah satu raja yang pernah berkuasa di Minangkabau antara1347-1375 M. Dalam tinjauan sejarah, Raja Adityawarman merupakan salah satu raja Minangkabau yang berasal dari trah kebangsawanan Majapahit.Raja Adityawarman sendiri diperkirakan berkuasa pada era yang sama dengan periode sejarah saat Gajah Mada menjabat sebagai Mahapatih (1334-1364 M).",
      event: ""),
  Place(
      imageUrl: "assets/rumah-kelahiran bung-hatta.png",
      city: "Kelahiran Bung Hatta",
      country: "Indonesia",
      description:
          "Rumah Kelahiran Bung Hatta adalah rumah yang dibangun sebagai upaya mengenang dan memperoleh gambaran tempat Bung Hatta dilahirkan dan menghabiskan masa kecilnya sampi berusia 11 tahun. Selanjutnya Bung Hatta melanjutkan pendidikan menengahnya di Meer Uitgebred Lager Onderwijs atau sekolah menengah di kota Padang.",
      event: "Rumah Kelahiran Bung Hatta"),
  Place(
      imageUrl: "assets/istano-basa-pagaruyuang.png",
      city: "Istano basa pagaruyuang",
      country: "Indonesia",
      description:
          "Istano Basa yang lebih terkenal dengan nama Istana Pagaruyung adalah museum berupa replika istana Kerajaan Pagaruyung terletak di Nagari Pagaruyung, Kecamatan Tanjung Emas, Kabupaten Tanah Datar, Sumatra Barat. Istana ini berjarak lebih kurang 5 kilometer dari Batusangkar.",
      event: ""),
];
