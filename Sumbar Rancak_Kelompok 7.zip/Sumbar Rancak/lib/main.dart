import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:travel_app/theme.dart';
import 'package:travel_app/views/pages/chat_page.dart';
import 'package:travel_app/views/pages/favorite_page.dart';
import 'package:travel_app/views/pages/main_page.dart';
import 'package:travel_app/views/pages/profile_page.dart';
import 'package:travel_app/views/pages/welcome_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WelcomeScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    MainPage(),
    FavoritePage(),
    ChatPage(),
    ProfilePage(),
  ];

  void _setIndex(value) {
    setState(() {
      _currentIndex = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: customNavBar(
        _currentIndex,
        (val) => _setIndex(val),
      ),
    );
  }
}

NavigationBarTheme customNavBar(int currentIndex, setIndex) {
  return NavigationBarTheme(
    data: NavigationBarThemeData(
      height: 46,
      backgroundColor: bgColor2,
      indicatorColor: Colors.white.withOpacity(0.7),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysHide,
      labelTextStyle: MaterialStateProperty.all(
        GoogleFonts.poppins(
          textStyle: TextStyle(
            color: Colors.grey[100],
            fontWeight: FontWeight.w500,
            letterSpacing: 1.4,
            fontSize: 12,
          ),
        ),
      ),
      iconTheme: MaterialStateProperty.all(
        IconThemeData(
          color: Colors.grey[100],
          size: 28,
        ),
      ),
    ),
    child: NavigationBar(
      selectedIndex: currentIndex,
      onDestinationSelected: setIndex,
      destinations: [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          label: 'Home',
          selectedIcon: Icon(
            Icons.home_rounded,
            color: mainCOlor,
          ),
        ),
        NavigationDestination(
          icon: Icon(Icons.favorite_rounded),
          label: 'Favorite',
          selectedIcon: Icon(
            Icons.favorite_rounded,
            color: mainCOlor,
          ),
        ),
        NavigationDestination(
          icon: Icon(Icons.chat_bubble),
          label: 'Chat',
          selectedIcon: Icon(Icons.chat_bubble, color: mainCOlor),
        ),
        NavigationDestination(
          icon: Icon(Icons.person_rounded),
          label: 'Profile',
          selectedIcon: Icon(Icons.person_rounded, color: mainCOlor),
        ),
      ],
    ),
  );
}
