import 'package:flutter/material.dart';
import 'package:travel_app/models/place.dart';
import 'package:travel_app/views/widgets/event.dart';

class FavoritePage extends StatelessWidget {
  const FavoritePage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.only(top: 40, right: 30, left: 30),
        child: ListView.builder(
            itemCount: events.length,
            scrollDirection: Axis.vertical,
            itemBuilder: (_, index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Event(events[index]),
              );
            }),
      ),
    );
  }
}
